import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Header from './components/Header';
import Footer from './components/Footer';

const App: React.FC = () => {
    return (
        <Router>
            <Header />
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/home" element={<Home />} />
                <Route path="/product-detail/:id" element={<ProductDetail />} />
                <Route path="/login" element={<Login />} />
                <Route path="/admin/products/create" element={<Create />} />
            </Routes>
            <Footer />
        </Router>
    );
}

export default App;
