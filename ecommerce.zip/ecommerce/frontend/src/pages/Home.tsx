import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/heroic-features.css';

const Home: React.FC = () => {
    const [message, setMessage] = useState('Welcome');

    useEffect(() => {
        // Aquí puedes hacer una llamada a la API si es necesario
        fetch('/api/home')
            .then(response => response.json())
            .then(data => setMessage(data.message))
            .catch(error => console.error('Error fetching data:', error));
    }, []);

    return (
        <div className="container">
            <header className="jumbotron my-4">
                <h1 className="display-3">{message}</h1>
                <p className="lead">Tu tienda de software en Línea</p>
            </header>
            <div className="row text-center">
                <div className="col-lg-3 col-md-6 mb-4">
                    <div className="card h-100">
                        <img className="card-img-top" src="/images/Logo.jpg" alt="Logo" />
                        <div className="card-body">
                            <h4 className="card-title">Agile Strategy</h4>
                            <p className="card-text">in business from IT</p>
                        </div>
                        <div className="card-footer">
                            <a href="http://www.sudoagile.com" className="btn btn-primary">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Home;
