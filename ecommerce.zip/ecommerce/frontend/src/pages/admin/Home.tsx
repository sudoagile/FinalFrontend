import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/heroic-features.css';
import Header from '../components/Header';
import Footer from '../components/Footer';

const products = [
    // Aquí deberías añadir los productos de tu base de datos
    {
        id: 1,
        name: 'Nombre del producto',
        image: '/images/producto1.jpg'
    },
    {
        id: 2,
        name: 'Nombre del producto 2',
        image: '/images/producto2.jpg'
    }
    // Añadir más productos según sea necesario
];

const Home: React.FC = () => {
    return (
        <div>
            <Header />
            <div className="container">
                <header className="jumbotron my-4">
                    <h1 className="display-3">Bienvenido a Spring Ecommerce 2024</h1>
                    <p className="lead">Tu tienda de productos en Línea</p>
                </header>

                <div className="row text-center">
                    {products.map(product => (
                        <div className="col-lg-3 col-md-6 mb-4" key={product.id}>
                            <div className="card h-100">
                                <img className="card-img-top" src={product.image} alt="" />
                                <div className="card-body">
                                    <p className="card-text">{product.name}</p>
                                </div>
                                <div className="card-footer">
                                    <a href="productohome.html" className="btn btn-success">Ver producto</a>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default Home;
