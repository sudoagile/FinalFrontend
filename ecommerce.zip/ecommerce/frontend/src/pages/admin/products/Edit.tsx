import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const Edit: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState('');
    const [img, setImg] = useState<File | null>(null);

    useEffect(() => {
        // Fetch product data using id
        fetch(`/admin/products/${id}`)
            .then(response => response.json())
            .then(data => {
                setName(data.name);
                setDescription(data.description);
                setPrice(data.price);
            })
            .catch(error => console.error('Error fetching product data:', error));
    }, [id]);

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('id', id || '');
        formData.append('name', name);
        formData.append('description', description);
        formData.append('price', price);
        if (img) {
            formData.append('img', img);
        }

        fetch('/admin/products/save-product', {
            method: 'POST',
            body: formData,
        })
            .then(response => response.json())
            .then(data => {
                console.log(data);
            })
            .catch(error => {
                console.error('Error:', error);
            });
    };

    return (
        <div className="container">
            <h1 className="mt-4 mb-3">
                Spring eCommerce <small>Productos</small>
            </h1>

            <ol className="breadcrumb">
                <li className="breadcrumb-item"><a href="/admin">Home</a></li>
                <li className="breadcrumb-item active">Actualizar Producto</li>
            </ol>

            <h2>Actualizar Producto</h2>
            <form className="form-horizontal" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label className="control-label col-sm-2" htmlFor="name">Nombre:</label>
                    <div className="col-sm-10">
                        <input
                            type="text"
                            className="form-control"
                            id="name"
                            name="name"
                            placeholder="Ingrese el nombre del producto"
                            value={name}
                            onChange={e => setName(e.target.value)}
                            required
                        />
                    </div>
                </div>

                <div className="form-group">
                    <label className="control-label col-sm-2" htmlFor="description">Descripción:</label>
                    <div className="col-sm-10">
                        <textarea
                            className="form-control"
                            id="description"
                            name="description"
                            placeholder="Ingrese la descripcion del producto"
                            value={description}
                            onChange={e => setDescription(e.target.value)}
                            required
                        />
                    </div>
                </div>

                <div className="form-group">
                    <label className="control-label col-sm-2" htmlFor="price">Precio:</label>
                    <div className="col-sm-10">
                        <input
                            type="number"
                            className="form-control"
                            step="any"
                            id="price"
                            name="price"
                            placeholder="Ingrese el precio del producto"
                            value={price}
                            onChange={e => setPrice(e.target.value)}
                            required
                        />
                    </div>
                </div>

                <div className="form-group">
                    <label className="control-label col-sm-2" htmlFor="img">Imagen:</label>
                    <div className="col-sm-10">
                        <input
                            type="file"
                            className="form-control-file"
                            id="img"
                            name="img"
                            onChange={e => setImg(e.target.files ? e.target.files[0] : null)}
                        />
                    </div>
                </div>

                <div className="row">
                    <div className="col-sm-2">
                        <button type="submit" className="btn btn-success">
                            Guardar
                        </button>
                    </div>
                </div>
            </form>
        </div>
    );
};

export default Edit;
