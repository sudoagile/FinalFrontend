import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/heroic-features.css';
import Header from './components/Header';
import Footer from './components/Footer';

const Show: React.FC = () => {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        // Reemplaza la URL con tu endpoint real para obtener los productos
        fetch('/api/products')
            .then((response) => response.json())
            .then((data) => setProducts(data))
            .catch((error) => console.error('Error fetching products:', error));
    }, []);

    return (
        <div>
            <Header />
            <div className="container">
                <h1 className="mt-4 mb-3">
                    Spring eCommerce <small>Productos</small>
                </h1>
                <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                        <a href="/admin">Home</a>
                    </li>
                    <li className="breadcrumb-item active">Ver Productos</li>
                </ol>
                <a className="btn btn-primary" href="/admin/products/create">
                    Crear Producto
                </a>
                <h2>Productos</h2>
                <table className="table">
                    <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Descripción</th>
                        <th scope="col">Precio</th>
                        <th scope="col">Editar</th>
                        <th scope="col">Eliminar</th>
                        <th scope="col">Inventario</th>
                    </tr>
                    </thead>
                    <tbody>
                    {products.map((product: any) => (
                        <tr key={product.id}>
                            <td>{product.name}</td>
                            <td>{product.description}</td>
                            <td>{product.price}</td>
                            <td>
                                <a className="btn btn-warning" href={`/admin/products/edit/${product.id}`}>
                                    Editar
                                </a>
                            </td>
                            <td>
                                <a className="btn btn-danger" href={`/admin/products/delete/${product.id}`}>
                                    Eliminar
                                </a>
                            </td>
                            <td>
                                <a className="btn btn-danger" href={`/admin/products/stock/${product.id}`}>
                                    Inventario
                                </a>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
            <Footer />
        </div>
    );
};

export default Show;
