import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/heroic-features.css';

const Show: React.FC = () => {
    const stocks = [
        { dateCreated: '2024-07-19', unitIn: 100, unitOut: 20, description: 'Stock inicial', balance: 80 },
        { dateCreated: '2024-07-20', unitIn: 50, unitOut: 10, description: 'Reposición', balance: 120 },
        // Agrega más datos de ejemplo aquí
    ];

    const idproduct = 1; // Ejemplo de ID de producto, cámbialo según sea necesario

    return (
        <div className="container">
            <h1 className="mt-4 mb-3">
                Spring eCommerce <small>Inventario</small>
            </h1>

            <ol className="breadcrumb">
                <li className="breadcrumb-item"><a href="/home">Home</a></li>
                <li className="breadcrumb-item active">Ver Inventario</li>
            </ol>

            <a className="btn btn-primary" href={`/admin/products/stock/create-unit-product/${idproduct}`}>Añadir unidades</a>
            <h2>Inventario</h2>
            <table className="table">
                <thead>
                <tr>
                    <th scope="col">Fecha Registro</th>
                    <th scope="col">Entrada/Unidades</th>
                    <th scope="col">Salida/Unidades</th>
                    <th scope="col">Descripción</th>
                    <th scope="col">Saldo/Unidades</th>
                </tr>
                </thead>
                <tbody>
                {stocks.map((stock, index) => (
                    <tr key={index}>
                        <td>{stock.dateCreated}</td>
                        <td>{stock.unitIn}</td>
                        <td>{stock.unitOut}</td>
                        <td>{stock.description}</td>
                        <td>{stock.balance}</td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
};

export default Show;
