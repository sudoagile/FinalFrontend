import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Create: React.FC = () => {
    return (
        <>
            {/* Navigation */}
            <header>
                {/* Inserta aquí el componente Header */}
            </header>

            {/* Page Content */}
            <div className="container">
                {/* Page Heading/Breadcrumbs */}
                <h1 className="mt-4 mb-3">
                    Spring eCommerce <small>Productos</small>
                </h1>

                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><a href="/admin">Home</a></li>
                    <li className="breadcrumb-item active">Añadir unidades</li>
                </ol>

                <h2>Añadir</h2>
                <form className="form-horizontal" action="/admin/products/stock/save-unit-product" method="post">
                    <input type="hidden" name="idproduct" value={/* Inserta el valor idproduct aquí */} />
                    <div className="form-group">
                        <label className="control-label col-sm-2" htmlFor="unitIn">Cantidad:</label>
                        <div className="col-sm-10">
                            <input type="number" className="form-control" id="unitIn"
                                   name="unitIn" placeholder="Ingrese la cantidad del producto"
                                   required autoComplete="off" />
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-sm-2">
                            <button type="submit" className="btn btn-success">
                                Guardar
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            {/* /.container */}

            {/* Footer */}
            <footer>
                {/* Inserta aquí el componente Footer */}
            </footer>

            {/* Bootstrap core JavaScript */}
            {/* Si necesitas jQuery y Bootstrap JS, instala las dependencias correspondientes */}
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
        </>
    );
};

export default Create;
