import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const TemplateAdmin: React.FC = ({ children }) => {
    return (
        <>
            <header>
                <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
                    <div className="container">
                        <a className="navbar-brand" href="/admin">Spring eCommerce</a>

                        <form className="form-inline my-2 my-lg-0" method="post" action="#">
                            <input className="form-control mr-sm-2" type="search" placeholder="Buscar" aria-label="Search" name="nombre" autoComplete="off" />
                            <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
                        </form>

                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarResponsive">
                            <ul className="navbar-nav ml-auto">
                                <li className="nav-item dropdown">
                                    <a className="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        ADMIN
                                    </a>
                                    <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                        <a className="dropdown-item" href="/admin/products/show">Productos</a>
                                        <a className="dropdown-item" href="/logout">Salir</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>

            <main className="container">
                {children}
            </main>

            <footer className="py-5 bg-dark">
                <div className="container">
                    <p className="m-0 text-center text-white">Copyright &copy; Spring eCommerce 2023</p>
                </div>
            </footer>
        </>
    );
};

export default TemplateAdmin;
