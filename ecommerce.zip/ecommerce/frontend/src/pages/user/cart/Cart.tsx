import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/heroic-features.css';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface CartItem {
    idProduct: number;
    nameProduct: string;
    price: number;
    quantity: number;
    getTotalPriceItem: () => number;
}

const Cart: React.FC = () => {
    const [cart, setCart] = useState<CartItem[]>([]);
    const [total, setTotal] = useState<number>(0);

    useEffect(() => {
        // Simula la obtención de datos del carrito desde una API
        fetch('/api/cart')
            .then(response => response.json())
            .then(data => {
                setCart(data);
                calculateTotal(data);
            })
            .catch(error => console.error('Error fetching cart data:', error));
    }, []);

    const calculateTotal = (items: CartItem[]) => {
        const total = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
        setTotal(total);
    };

    const handleRemoveItem = (idProduct: number) => {
        // Aquí deberías hacer una llamada a la API para eliminar el producto del carrito
        fetch(`/api/cart/delete-item/${idProduct}`, { method: 'DELETE' })
            .then(() => {
                const updatedCart = cart.filter(item => item.idProduct !== idProduct);
                setCart(updatedCart);
                calculateTotal(updatedCart);
            })
            .catch(error => console.error('Error removing item from cart:', error));
    };

    return (
        <div>
            <Header />
            <div className="container">
                <h1 className="mt-4 mb-3">
                    Spring eCommerce <small>Carrito</small>
                </h1>

                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><a href="/home">Home</a></li>
                    <li className="breadcrumb-item active">Carrito</li>
                </ol>

                <div className="card mb-4">
                    <div className="card-body">
                        <div className="row">
                            <div className="col-lg-9">
                                <table className="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">Producto</th>
                                        <th scope="col">Precio</th>
                                        <th scope="col">Cantidad</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Acción</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {cart.map(item => (
                                        <tr key={item.idProduct}>
                                            <td>{item.nameProduct}</td>
                                            <td>{item.price}</td>
                                            <td>{item.quantity}</td>
                                            <td>{item.price * item.quantity}</td>
                                            <td>
                                                <button
                                                    className="btn btn-danger"
                                                    onClick={() => handleRemoveItem(item.idProduct)}
                                                >
                                                    Quitar
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                    </tbody>
                                </table>
                            </div>

                            <div className="col-lg-3">
                                <h2 className="card-title">SUBTOTAL</h2>
                                <ul className="list-group">
                                    <li className="list-group-item">
                                        <h5>Total: ${total}</h5>
                                    </li>
                                    <a href="/user/order/sumary-order" className="btn btn-dark">Ver Orden</a>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default Cart;
