import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/heroic-features.css';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface User {
    firstName: string;
    lastName: string;
    email: string;
    address: string;
}

interface CartItem {
    nameProduct: string;
    price: number;
    quantity: number;
    getTotalPriceItem: () => number;
}

const SummaryOrder: React.FC = () => {
    const [user, setUser] = useState<User | null>(null);
    const [cart, setCart] = useState<CartItem[]>([]);
    const [total, setTotal] = useState<number>(0);

    useEffect(() => {
        // Simula la obtención de datos del usuario y del carrito desde una API
        fetch('/api/user')
            .then(response => response.json())
            .then(data => setUser(data))
            .catch(error => console.error('Error fetching user data:', error));

        fetch('/api/cart')
            .then(response => response.json())
            .then(data => {
                setCart(data);
                calculateTotal(data);
            })
            .catch(error => console.error('Error fetching cart data:', error));
    }, []);

    const calculateTotal = (items: CartItem[]) => {
        const total = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
        setTotal(total);
    };

    const handleCreateOrder = () => {
        // Aquí deberías hacer una llamada a la API para crear la orden
        fetch('/api/user/order/create-order', {
            method: 'POST',
        })
            .then(response => response.json())
            .then(data => {
                console.log('Orden generada:', data);
            })
            .catch(error => console.error('Error creating order:', error));
    };

    if (!user) {
        return <div>Cargando...</div>;
    }

    return (
        <div>
            <Header />
            <div className="container">
                <h1 className="mt-4 mb-3">
                    Spring eCommerce <small>Resumen de la orden</small>
                </h1>

                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><a href="/home">Home</a></li>
                    <li className="breadcrumb-item active">Orden</li>
                </ol>

                <div className="card mb-4">
                    <div className="card-body">
                        <div className="row">
                            <div className="col-lg-9">
                                <div className="card-body">
                                    <h5 className="card-title">DATOS ORDEN</h5>
                                    <h6>Nombre: {user.firstName} {user.lastName}</h6>
                                    <h6>Correo: {user.email}</h6>
                                    <h6>Dirección: {user.address}</h6>

                                    <h5 className="card-title">PRODUCTOS</h5>
                                    <div className="alert alert-light" role="alert">
                                        <table className="table">
                                            <thead>
                                            <tr>
                                                <th scope="col">Producto</th>
                                                <th scope="col">Precio</th>
                                                <th scope="col">Cantidad</th>
                                                <th scope="col">Total</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            {cart.map((item, index) => (
                                                <tr key={index}>
                                                    <td>{item.nameProduct}</td>
                                                    <td>{item.price}</td>
                                                    <td>{item.quantity}</td>
                                                    <td>{item.price * item.quantity}</td>
                                                </tr>
                                            ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div className="col-lg-3">
                                <h2 className="card-title">Resumen Orden</h2>
                                <ul className="list-group">
                                    <li className="list-group-item"><h5>Total: ${total}</h5></li>
                                    <button onClick={handleCreateOrder} className="btn btn-dark">Generar</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default SummaryOrder;
