import React from 'react';
import TemplateUser from '../components/TemplateUser';

const UserPage: React.FC = () => {
    return (
        <TemplateUser>
            <h1>Contenido de la página de usuario</h1>
            {/* Más contenido aquí */}
        </TemplateUser>
    );
};

export default UserPage;
