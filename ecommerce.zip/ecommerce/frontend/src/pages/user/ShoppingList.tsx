import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/heroic-features.css';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface Order {
    id: number;
    dateCreated: string;
    getTotalOrderPrice: () => number;
}

const ShoppingList: React.FC = () => {
    const [orders, setOrders] = useState<Order[]>([]);

    useEffect(() => {
        // Reemplaza esta URL con el endpoint de tu API para obtener las órdenes de compra
        fetch('/api/orders')
            .then(response => response.json())
            .then(data => setOrders(data))
            .catch(error => console.error('Error fetching orders:', error));
    }, []);

    return (
        <div>
            <Header />
            <div className="container">
                <h1 className="mt-4 mb-3">
                    Spring eCommerce <small>Compras</small>
                </h1>

                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><a href="/home">Home</a></li>
                    <li className="breadcrumb-item active">Compras</li>
                </ol>

                <div className="card mb-4">
                    <div className="card-body">
                        <div className="row">
                            <div className="col-lg-12">
                                <table className="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">Id</th>
                                        <th scope="col">Fecha</th>
                                        <th scope="col">Valor</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {orders.map(order => (
                                        <tr key={order.id}>
                                            <td>{order.id}</td>
                                            <td>{order.dateCreated}</td>
                                            <td>{order.getTotalOrderPrice()}</td>
                                        </tr>
                                    ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default ShoppingList;
