import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/heroic-features.css';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface Product {
    id: number;
    name: string;
    price: number;
    description: string;
    image: string;
}

const ProductDetail: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const [product, setProduct] = useState<Product | null>(null);
    const [stock, setStock] = useState<number>(0);
    const [quantity, setQuantity] = useState<number>(1);

    useEffect(() => {
        // Reemplaza estas rutas con las rutas reales de tu API
        fetch(`/api/products/${id}`)
            .then(response => response.json())
            .then(data => {
                setProduct(data.product);
                setStock(data.stock);
            })
            .catch(error => console.error('Error fetching product data:', error));
    }, [id]);

    const handleAddToCart = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        // Aquí deberías hacer una llamada a la API para añadir el producto al carrito
        fetch('/api/cart/add-product', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                idProduct: product?.id,
                nameProduct: product?.name,
                price: product?.price,
                quantity: quantity,
            }),
        })
            .then(response => response.json())
            .then(data => {
                console.log('Producto añadido al carrito:', data);
            })
            .catch(error => console.error('Error adding product to cart:', error));
    };

    if (!product) {
        return <div>Cargando...</div>;
    }

    return (
        <div>
            <Header />
            <div className="container">
                <h1 className="mt-4 mb-3">
                    Spring eCommerce <small>Producto</small>
                </h1>

                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><a href="/home">Home</a></li>
                    <li className="breadcrumb-item active">Producto</li>
                </ol>

                <div className="card mb-4">
                    <div className="card-body">
                        <div className="row">
                            <div className="col-lg-6">
                                <img className="img-fluid rounded" src={`/images/${product.image}`} alt={product.name} />
                            </div>
                            <div className="col-lg-6">
                                <form onSubmit={handleAddToCart}>
                                    <input type="hidden" value={product.id} name="idProduct" />
                                    <input type="hidden" value={product.name} name="nameProduct" />
                                    <input type="hidden" value={product.price} name="price" />

                                    <h2 className="card-title">{product.name}</h2>

                                    <ul className="list-group">
                                        <li className="list-group-item"><h5>Precio: ${product.price}</h5></li>
                                        <li className="list-group-item"><h5>Stock: {stock} unidades</h5></li>
                                        <li className="list-group-item">
                                            <p>Descripción: {product.description}</p>
                                        </li>
                                        <li className="list-group-item">
                                            <h6>
                                                Cantidad: <input type="number" id="quantity" name="quantity" autoComplete="off" min="1" max="5" value={quantity} onChange={(e) => setQuantity(parseInt(e.target.value))} />
                                            </h6>
                                        </li>
                                    </ul>

                                    <button type="submit" className="btn btn-dark">Añadir al carrito</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default ProductDetail;
